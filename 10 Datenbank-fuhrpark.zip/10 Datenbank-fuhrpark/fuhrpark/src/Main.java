import view.HauptmenueView;

public class Main {
    public static void main(String[] args) {
        new HauptmenueView().starten();
    }
}
